```markdown
# Design System Specification: High-End Medical Editorial

## 1. Overview & Creative North Star
**Creative North Star: "The Clinical Sanctuary"**

This design system moves away from the cluttered, utility-first aesthetic of legacy medical software. Instead, it adopts a "Clinical Sanctuary" approach—blending the precision of a high-end editorial journal with the calming, ethereal quality of modern healthcare environments. 

We break the "template" look by rejecting rigid, boxed-in grids. Instead, we utilize **intentional asymmetry, expansive breathing room, and tonal depth**. The interface should feel like a series of layered, translucent surfaces rather than a flat screen. By prioritizing negative space and a sophisticated type hierarchy, we instill a sense of calm and clinical authority, ensuring that the critical data doctors and patients interact with is never obscured by visual noise.

---

## 2. Colors & Surface Philosophy
The palette is rooted in medical reliability but elevated through "Tonal Layering" to create a signature premium feel.

### The Palette
- **Primary (Authority):** `#003d9b` (Primary) / `#0052cc` (Primary Container). Used for critical actions and brand presence.
- **Secondary (Vitality):** `#006b59` (Secondary) / `#7cf8da` (Secondary Container). Used for health-positive indicators and supportive actions.
- **Tertiary (Urgency):** `#7b2600` (Tertiary) / `#a33500` (Tertiary Container). Reserved for alerts or critical patient notifications.
- **Neutrals:** A sophisticated range from `surface-container-lowest` (`#ffffff`) to `surface-dim` (`#d9dadc`).

### The "No-Line" Rule
To achieve a high-end feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined solely through background color shifts. 
*   *Implementation:* A dashboard widget (`surface-container-lowest`) should sit atop a main content area (`surface-container-low`), which in turn sits on the global `background` (`#f8f9fb`).

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine materials:
1.  **Level 0 (Background):** `background` (`#f8f9fb`) — The base canvas.
2.  **Level 1 (Sections):** `surface-container-low` — Used for sidebar backgrounds or large page sections.
3.  **Level 2 (Cards/Modules):** `surface-container-lowest` (`#ffffff`) — The primary interactive surface for data.

### The "Glass & Gradient" Rule
To avoid a "flat" corporate look, use subtle linear gradients on primary CTAs (transitioning from `primary` to `primary_container`). For floating elements like dropdowns or overlays, apply **Glassmorphism**: use a semi-transparent `surface` color with a 12px-16px backdrop-blur to allow underlying data to softly bleed through.

---

## 3. Typography
Our typography system uses two faces: **Manrope** for authoritative, editorial displays and **Inter** for clinical precision and data density.

| Role | Token | Font | Size | Character |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Manrope | 3.5rem | Bold, tight tracking (-2%). For hero stats. |
| **Headline**| `headline-md`| Manrope | 1.75rem | Semibold. Patient names or section starts. |
| **Title** | `title-md` | Inter | 1.125rem | Medium. Card headers and modal titles. |
| **Body** | `body-md` | Inter | 0.875rem | Regular. Standard medical notes and data. |
| **Label** | `label-sm` | Inter | 0.6875rem | Bold/Uppercase. Small captions or metadata. |

**The Editorial Scale:** We use extreme contrast between `display` and `body` sizes to guide the eye. Use `label-sm` in `on_surface_variant` for metadata to ensure it recedes, allowing primary data to shine.

---

## 4. Elevation & Depth
Depth is created through light and shadow, not lines.

- **The Layering Principle:** Instead of shadows, use "Tonal Lift." A white card (`surface-container-lowest`) on a light gray background (`surface-container-low`) provides enough contrast for the eye without the clutter of a shadow.
- **Ambient Shadows:** When a card must float (e.g., a critical "New Appointment" modal), use an ultra-diffused shadow: `0px 24px 48px rgba(25, 28, 30, 0.06)`. This mimics soft, overhead surgical lighting.
- **The "Ghost Border" Fallback:** If high-contrast accessibility is required, use the `outline-variant` token at **15% opacity**. Never use 100% opaque outlines.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `8px` (DEFAULT) rounded corners. Text in `on_primary`.
- **Secondary:** Surface-only. `secondary_container` background with `on_secondary_container` text. No border.
- **Tertiary:** Text-only in `primary` color. Use for low-priority actions like "Cancel."

### Data Tables (The Clinical Ledger)
**Forbid the use of divider lines.**
- **Header:** `surface-container-high` background with `label-md` text.
- **Rows:** Alternate between `surface-container-lowest` and `surface-container-low` on hover. 
- **Cell Content:** Use `body-md` for data. Use `secondary` or `primary` colored text for actionable IDs.

### Status Badges
- Soft, pill-shaped (`full` roundedness).
- **Positive:** `secondary_fixed` background with `on_secondary_fixed_variant` text.
- **Warning:** `tertiary_fixed` background with `on_tertiary_fixed_variant` text.

### Form Inputs
- **Static State:** `surface-container-highest` background, no border. `8px` radius.
- **Focus State:** 2px solid `primary`. 
- **Validation:** Error states use `error` and `error_container` for the background fill to ensure the field is impossible to miss.

### Navigation (The Vertical Spine)
- **Side Nav:** `surface-container-low` background. 
- **Active Item:** An asymmetrical "pill" indicator on the left in `primary`, with a soft `primary_fixed` background highlight for the entire row.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `xl` (1.5rem) roundedness for large layout containers to soften the medical environment.
- **Do** use significant vertical padding (48px+) between major sections to reduce cognitive load for busy doctors.
- **Do** use "surface-tint" overlays at 5% opacity to give white cards a slight "medical blue" cooling effect.

### Don’t
- **Don't** use 1px dividers between list items; use 8px–12px of vertical white space instead.
- **Don't** use pure black `#000000` for text; always use `on_surface` (`#191c1e`) to maintain a premium, softer look.
- **Don't** cram data. If a table has 15 columns, use a horizontal scroll on a layered surface rather than shrinking the typography.```